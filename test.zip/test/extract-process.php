<?php
if(isset($_POST["url"]))
{
	$get_url = $_POST["url"]; 
		
		
		
		$c = get_data($get_url);
		
		$d = new DomDocument();
		
		$d->loadHTML($c);
		$xp = new domxpath($d);
		foreach ($xp->query("//meta[@property='og:title']") as $el) {
		    $data['title']= $el->getAttribute("content");
		}
		if(!isset($data['title']))
		{
			$data['title']=$xp->query('//title')->item(0)->nodeValue."\n";
		}
		foreach ($xp->query("//meta[@property='og:description']") as $el) {
		    $data['desc']= $el->getAttribute("content");
		}
		if(!isset($data['desc']))
		{
			foreach ($xp->query("//meta[@name='description']") as $el) {
			    $data['desc']= $el->getAttribute("content");
			}
			if(!isset($data['desc']))
			{
				$str = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $c);
				$str = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $str);
				$str = preg_replace('#<header(.*?)>(.*?)</header>#is', '', $str);
				$str = preg_replace('#<head(.*?)>(.*?)</head>#is', '', $str);
				$str = preg_replace('#<a(.*?)>(.*?)</a>#is', '', $str);
				$str = str_replace('|', '', $str);
				//$data['desc']= substr(trim(preg_replace('/\s+/',' ',strip_tags($str)),''),0,100);
				$data['desc']= substr(trim(preg_replace('/\s+/',' ',strip_tags($str)),''),0,100);
				//print_r($matches);
			}
		}
		foreach ($xp->query("//meta[@property='og:image']") as $el) {
		    $data['image']= $el->getAttribute("content");
		}

		if(!isset($data['image']))
		{
			//echo "here";
			$nodelist=$xp->query("//img");
			$node = $nodelist->item(0); // gets the 1st image
			$value = $node->attributes->getNamedItem('src')->nodeValue;
			if(strpos($value,'http')!==false)
			{
				$data['image']= $value;
			}
			else
			{
				$url=parse_url($get_url);
				//print_r($url);
				$data['image']=$url['scheme'].'://'.$url['host'].$value;
			}
			/*foreach ($xp->query("//img") as $el) {
				print_r($el);
				//echo $el->getAttribute("src");
			}*/
		}
		foreach ($xp->query("//meta[@property='og:url']") as $el) {
		    $data['url']= $el->getAttribute("content");
		}
		if(!isset($data['url']))
		{
			$data['url']=$get_url;
		}
		echo json_encode($data);
}
function get_data($url) {
	$ch = curl_init();
	
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
	$data = curl_exec($ch);
	curl_close($ch);
	return $data;
}
?>